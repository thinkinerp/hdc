/**
 * 
 */
//var curWwwPath=window.document.location.href;
//var pathName=window.document.location.pathname;
//var pos=curWwwPath.indexOf(pathName);
//var domainName = curWwwPath.substring(0,pos);
//if("http://www.onetoend.cn" == domainName){
//	domainName = 'http://120.76.214.173:80';
//}

var domainName=  "http://www.onetoend.cn";